import SwiftUI


func getJSON<T: Decodable>(urlString: String, completion: @escaping (T?) -> Void) {
    guard let url = URL(string: urlString) else {
        return
    }
    let request = URLRequest(url: url)
    URLSession.shared.dataTask(with: request) { (data, response, error) in
        if let error = error {
            print(error.localizedDescription)
            completion(nil)
            return
        }
        guard let data = data else {
            completion(nil)
            return
        }
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .secondsSince1970
        guard let decodedData = try? decoder.decode(T.self, from: data) else {
            completion(nil)
            return
        }
        completion(decodedData)
    }.resume()
}

struct CategoryInfo: Decodable {
    let idCategory: String
    let strCategory: String
    let strCategoryThumb: String
    let strCategoryDescription: String
}

struct CategoriesJSON: Decodable {
    let categories: [CategoryInfo]

}

var catInfo: [CategoryInfo] = [CategoryInfo]()
var catNames: [String] = []
var catImages: [String] = []
var catDescriptions: [String] = []


//getJSON(urlString: "https://www.themealdb.com/api/json/v1/1/categories.php") { (data: CategoriesJSON?) in
//    if let data = data {
//
//        catInfo = data.categories
//
//        for i in catInfo {
//            catNames.append(i.strCategory)
//            catImages.append(i.strCategoryThumb)
//            catDescriptions.append(i.strCategoryDescription)
//
//        }
//
//        print(catNames)
//        print(catImages)
//        print(catDescriptions)
//    }
//}

struct Meal: Decodable {
    let strMeal: String
    let strMealThumb: String
    let idMeal: String
}

struct Meals: Decodable {
    let meals: [Meal]
}


var mealInfo: [Meal] = [Meal]()
var mealNames: [String] = []
var mealImages: [String] = []
var mealId: [String] = []
var selectedCategory: String = "Seafood"

getJSON(urlString: "https://www.themealdb.com/api/json/v1/1/filter.php?c=" + selectedCategory) { (data: Meals?) in
    if let data = data {
        mealInfo = data.meals

//        for i in mealInfo {
//            mealNames.append(i.strMeal)
//            mealImages.append(i.strMealThumb)
//            mealId.append(i.idMeal)
//        }
    }
}

struct Recipie: Decodable {
    let idMeal: String
    let strMeal: String
    let strArea: String
    let strInstructions: String
}

struct RecipieJSON: Decodable {
    let recipieJSON: Recipie
}

var recipieStuff: [Recipie] = [Recipie]()
var recipieInfo: Recipie = Recipie(idMeal: "", strMeal: "", strArea: "", strInstructions: "")
var recipieOrigin: String = ""
var recipieId: String = "52772"

//getJSON(urlString: "https://www.themealdb.com/api/json/v1/1/lookup.php?i=52772") { (data: RecipieStuff?) in
//    if let data = data {
//        recipieStuff = data.recipieStuff
//
//        print(recipieStuff)
//
//        //print(recipieOrigin)
//    }
//}

//getJSON(urlString: "https://www.themealdb.com/api/json/v1/1/lookup.php?i=" + recipieId) { (data: RecipieJSON?) in
//    if let data = data {
//        recipieStuff = data.recipieJSON
//
//        print(recipieStuff)
//
//    }
//}

struct Recipie2: Decodable {
    struct Meals: Decodable {
        let idMeal: String
        let strMeal: String
        let strArea: String
        let strInstructions: String
    }
    let results: [Meals]
}

var recipieI: [Recipie2.Meals] = [Recipie2.Meals]()

getJSON(urlString: "https://www.themealdb.com/api/json/v1/1/lookup.php?i=52772") { (data: Recipie2?) in
    if let data = data {
        recipieI = data.results
        
        
        print(recipieI)
    }
}


